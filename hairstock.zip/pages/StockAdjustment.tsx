import React, { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Icon } from '../components/Icon';
import { Product } from '../types';

export const StockAdjustment: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const product = location.state?.product as Product;

  const [inputVal, setInputVal] = useState<string>('0');
  const [operation, setOperation] = useState<'add' | 'subtract' | null>('add'); // Default to add
  const [notes, setNotes] = useState<string>('');
  const [showConfirmation, setShowConfirmation] = useState(false);

  if (!product) {
    return <div className="p-4">Loading...</div>;
  }

  const currentStock = product.quantity;
  const adjustAmount = parseInt(inputVal) || 0;
  
  const finalStock = operation === 'add' 
    ? currentStock + adjustAmount 
    : currentStock - adjustAmount;

  const handleNumClick = (num: string) => {
    if (inputVal === '0') {
      setInputVal(num);
    } else {
      if (inputVal.length < 5) {
        setInputVal(inputVal + num);
      }
    }
  };

  const handleBackspace = () => {
    if (inputVal.length > 1) {
      setInputVal(inputVal.slice(0, -1));
    } else {
      setInputVal('0');
    }
  };

  const handleClear = () => {
    setInputVal('0');
  };

  const handleUpdateClick = () => {
    if (adjustAmount === 0) return;
    setShowConfirmation(true);
  };

  const handleConfirmAction = () => {
    // Logic to update global state/API would go here
    console.log(`Transaction Confirmed: ${operation} ${adjustAmount} for ${product.name}`);
    console.log('Notes:', notes);
    setShowConfirmation(false);
    navigate(-1);
  };

  return (
    <div className="relative mx-auto h-screen w-full max-w-md overflow-hidden bg-background-light dark:bg-background-dark shadow-2xl flex flex-col">
      <div className="bg-background-light dark:bg-background-dark z-10 shrink-0">
        <div className="pt-2 pb-1 w-full flex justify-center cursor-pointer" onClick={() => navigate(-1)}>
          <div className="h-1.5 w-12 rounded-full bg-slate-300 dark:bg-slate-600"></div>
        </div>
        
        <div className="relative flex items-center justify-center px-4 py-2">
            <button 
              onClick={() => navigate(-1)} 
              className="absolute left-4 p-2 rounded-full hover:bg-black/5 dark:hover:bg-white/10 transition-colors text-slate-900 dark:text-white z-20"
            >
               <Icon name="arrow_back" className="text-2xl" />
            </button>
            
            <div className="text-center w-full px-12">
                <h1 className="text-slate-900 dark:text-white text-lg font-semibold tracking-tight">库存调整</h1>
                <p className="text-slate-500 dark:text-slate-400 text-xs font-medium truncate">{product.name} {product.variant}</p>
            </div>
        </div>
      </div>

      <div className="px-4 py-3 shrink-0">
        <div className="bg-white dark:bg-card-dark rounded-3xl p-5 shadow-sm border border-slate-100 dark:border-slate-700 flex flex-col items-center justify-center space-y-4">
          <div className="flex w-full justify-between px-4 text-xs font-semibold uppercase tracking-wider text-slate-400">
            <span>当前</span>
            <span>调整</span>
            <span>新总量</span>
          </div>
          <div className="flex w-full items-center justify-between">
            <div className="flex flex-col items-center">
              <span className="text-3xl font-bold text-slate-400 dark:text-slate-500">{currentStock}</span>
            </div>
            
            <div className={`flex h-8 w-8 items-center justify-center rounded-full ${operation === 'add' ? 'bg-calculator-orange/10 text-calculator-orange' : 'bg-calculator-orange/10 text-calculator-orange'}`}>
              <Icon name={operation === 'add' ? "add" : "remove"} className="text-xl font-bold" />
            </div>

            <div className="flex flex-col items-center relative group">
              <span className="text-5xl font-bold text-slate-900 dark:text-white transition-all">{adjustAmount}</span>
              <div className="absolute -bottom-2 h-1 w-full rounded-full bg-calculator-orange opacity-100 animate-pulse"></div>
            </div>

            <span className="text-2xl font-medium text-slate-300 dark:text-slate-600">=</span>

            <div className="flex flex-col items-center">
              <span className="text-5xl font-bold text-primary dark:text-blue-400 transition-all">{finalStock}</span>
            </div>
          </div>
          
          <div className="w-full pt-1">
            <div className="relative group">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Icon name="edit_note" className="text-slate-400 group-focus-within:text-primary transition-colors text-[20px]" />
              </div>
              <input 
                type="text" 
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="block w-full pl-10 pr-4 py-2.5 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/50 rounded-xl text-sm text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:bg-white dark:focus:bg-slate-800 transition-all" 
                placeholder="添加备注 (可选)..." 
              />
            </div>
          </div>
        </div>
      </div>

      <div className="flex-1 flex flex-col justify-end px-4 pb-6 pt-1">
        <div className="grid grid-cols-4 gap-3 w-full max-w-[360px] mx-auto">
          {['7', '8', '9'].map(num => (
            <button key={num} onClick={() => handleNumClick(num)} className="aspect-square w-full rounded-full bg-calculator-gray dark:bg-calculator-dark-gray hover:brightness-90 active:scale-95 transition-transform flex items-center justify-center shadow-sm">
              <span className="text-3xl font-medium text-slate-900 dark:text-white">{num}</span>
            </button>
          ))}
          <button 
            onClick={() => setOperation('add')}
            className={`aspect-square w-full rounded-full ${operation === 'add' ? 'bg-calculator-orange text-white ring-4 ring-orange-100 dark:ring-orange-900/30' : 'bg-calculator-orange text-white opacity-80'} active:scale-95 transition-all flex items-center justify-center shadow-lg shadow-orange-500/30`}
          >
            <Icon name="add" className="text-4xl" />
          </button>

          {['4', '5', '6'].map(num => (
            <button key={num} onClick={() => handleNumClick(num)} className="aspect-square w-full rounded-full bg-calculator-gray dark:bg-calculator-dark-gray hover:brightness-90 active:scale-95 transition-transform flex items-center justify-center shadow-sm">
              <span className="text-3xl font-medium text-slate-900 dark:text-white">{num}</span>
            </button>
          ))}
          <button 
             onClick={() => setOperation('subtract')}
             className={`aspect-square w-full rounded-full ${operation === 'subtract' ? 'bg-calculator-orange text-white ring-4 ring-orange-100 dark:ring-orange-900/30' : 'bg-calculator-orange text-white opacity-80'} active:scale-95 transition-transform flex items-center justify-center shadow-sm`}
          >
            <Icon name="remove" className="text-4xl" />
          </button>

          {['1', '2', '3'].map(num => (
            <button key={num} onClick={() => handleNumClick(num)} className="aspect-square w-full rounded-full bg-calculator-gray dark:bg-calculator-dark-gray hover:brightness-90 active:scale-95 transition-transform flex items-center justify-center shadow-sm">
              <span className="text-3xl font-medium text-slate-900 dark:text-white">{num}</span>
            </button>
          ))}
          <button onClick={handleBackspace} className="aspect-square w-full rounded-full bg-slate-300 dark:bg-slate-600 hover:brightness-90 active:scale-95 transition-transform flex items-center justify-center shadow-sm text-slate-800 dark:text-white">
            <Icon name="backspace" className="text-3xl" />
          </button>

          <button onClick={handleClear} className="aspect-square w-full rounded-full bg-slate-300 dark:bg-slate-600 hover:brightness-90 active:scale-95 transition-transform flex items-center justify-center shadow-sm">
            <span className="text-2xl font-medium text-slate-800 dark:text-white">C</span>
          </button>
          <button onClick={() => handleNumClick('0')} className="aspect-square w-full rounded-full bg-calculator-gray dark:bg-calculator-dark-gray hover:brightness-90 active:scale-95 transition-transform flex items-center justify-center shadow-sm">
            <span className="text-3xl font-medium text-slate-900 dark:text-white">0</span>
          </button>
          <button className="aspect-square w-full rounded-full bg-calculator-gray dark:bg-calculator-dark-gray hover:brightness-90 active:scale-95 transition-transform flex items-center justify-center shadow-sm">
            <span className="text-3xl font-medium text-slate-900 dark:text-white">.</span>
          </button>
          <div className="aspect-square w-full"></div> {/* Spacer */}
        </div>
      </div>

      <div className="px-4 pb-8 pt-2">
        <button 
          onClick={handleUpdateClick} 
          disabled={adjustAmount === 0}
          className={`w-full rounded-full bg-primary hover:bg-blue-600 active:scale-[0.98] transition-all text-white font-bold text-xl h-16 shadow-lg shadow-primary/30 flex items-center justify-center gap-3 ${adjustAmount === 0 ? 'opacity-50 grayscale' : ''}`}
        >
          <span>确认更新</span>
          <Icon name="check_circle" className="text-2xl" />
        </button>
      </div>

      {/* Confirmation Modal */}
      {showConfirmation && (
        <div className="absolute inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
          <div className="w-full max-w-sm bg-white dark:bg-[#1C1C1E] rounded-3xl p-6 shadow-2xl transform transition-all scale-100 border border-slate-100 dark:border-slate-800">
            <div className="flex flex-col items-center text-center gap-4">
              <div className={`flex items-center justify-center w-16 h-16 rounded-full ${operation === 'add' ? 'bg-green-100 text-green-600 dark:bg-green-900/30 dark:text-green-400' : 'bg-red-100 text-red-600 dark:bg-red-900/30 dark:text-red-400'} mb-1`}>
                <Icon name={operation === 'add' ? "add_business" : "outbound"} className="text-3xl" />
              </div>
              
              <h3 className="text-xl font-bold text-slate-900 dark:text-white">确认库存{operation === 'add' ? '入库' : '出库'}?</h3>
              
              <div className="w-full bg-background-light dark:bg-black/20 rounded-2xl p-4 space-y-3">
                <div className="flex justify-between text-sm">
                  <span className="text-slate-500 dark:text-slate-400">产品</span>
                  <span className="font-semibold text-slate-900 dark:text-white text-right truncate max-w-[60%]">{product.name}</span>
                </div>
                <div className="flex justify-between text-sm">
                   <span className="text-slate-500 dark:text-slate-400">调整数量</span>
                   <span className={`font-bold ${operation === 'add' ? 'text-green-600 dark:text-green-400' : 'text-red-500 dark:text-red-400'}`}>
                     {operation === 'add' ? '+' : '-'}{adjustAmount}
                   </span>
                </div>
                <div className="h-px bg-slate-200 dark:bg-slate-700"></div>
                <div className="flex justify-between text-base">
                  <span className="text-slate-500 dark:text-slate-400">更新后库存</span>
                  <span className="font-bold text-primary dark:text-blue-400">{finalStock}</span>
                </div>
              </div>

              <div className="flex gap-3 w-full mt-3">
                <button 
                  onClick={() => setShowConfirmation(false)}
                  className="flex-1 py-3.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-semibold hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
                >
                  取消
                </button>
                <button 
                  onClick={handleConfirmAction}
                  className="flex-1 py-3.5 rounded-xl bg-primary text-white font-semibold shadow-lg shadow-primary/30 hover:bg-blue-600 transition-colors"
                >
                  确认
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
