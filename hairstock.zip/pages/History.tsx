import React, { useState, useMemo } from 'react';
import { Icon } from '../components/Icon';

interface HistoryItem {
  id: string;
  type: 'in' | 'out';
  name: string;
  brand: string;
  amount: number;
  time: string;
  date: string;
  notes?: string;
}

const allTransactions: HistoryItem[] = [
  { id: '1', type: 'in', name: '漂粉', brand: '欧莱雅', amount: 12, time: '2小时前', date: '今天', notes: '新进货' },
  { id: '2', type: 'out', name: '调色剂 9.1', brand: '威娜', amount: 3, time: '5小时前', date: '今天' },
  { id: '3', type: 'in', name: '双氧乳 20 Vol', brand: '施华蔻', amount: 5, time: '下午4:30', date: '昨天' },
  { id: '4', type: 'out', name: '洗发水 (1L)', brand: '卡诗', amount: 1, time: '上午10:15', date: '昨天', notes: '员工领用' },
  { id: '5', type: 'in', name: '锡纸 500张', brand: 'Framar', amount: 20, time: '上午9:00', date: '2023年9月24日' },
];

export const History: React.FC = () => {
  const [filterType, setFilterType] = useState<'all' | 'in' | 'out'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [isExportMenuOpen, setIsExportMenuOpen] = useState(false);

  const groupedHistory = useMemo(() => {
    // 1. Filter
    const filtered = allTransactions.filter(item => {
      const matchesType = filterType === 'all' || item.type === filterType;
      const q = searchQuery.toLowerCase();
      const matchesSearch = item.name.toLowerCase().includes(q) || 
                            item.brand.toLowerCase().includes(q);
      return matchesType && matchesSearch;
    });

    // 2. Group by date
    // We use a Map to preserve insertion order (which assumes data is sorted by date descending)
    const groups = new Map<string, HistoryItem[]>();
    
    filtered.forEach(item => {
      if (!groups.has(item.date)) {
        groups.set(item.date, []);
      }
      groups.get(item.date)?.push(item);
    });

    return Array.from(groups.entries());
  }, [filterType, searchQuery]);

  const handleExport = (type: 'daily' | 'monthly') => {
    setIsExportMenuOpen(false);

    // 1. Filter Data based on selection (Mock logic)
    let dataToExport = allTransactions;
    let fileName = '';

    if (type === 'daily') {
      // Mock: Only export "Today" items
      dataToExport = allTransactions.filter(t => t.date === '今天');
      const today = new Date().toISOString().split('T')[0];
      fileName = `hairstock_daily_log_${today}.csv`;
    } else {
      // Mock: Export all items as "Monthly"
      dataToExport = allTransactions;
      const month = new Date().toISOString().slice(0, 7);
      fileName = `hairstock_monthly_log_${month}.csv`;
    }

    if (dataToExport.length === 0) {
      alert("所选时间段无数据可导出");
      return;
    }

    // 2. Define Headers
    const headers = ['ID', '日期', '时间', '类型', '产品名称', '品牌', '数量', '备注'];

    // 3. Map Data to Rows
    const rows = dataToExport.map(item => [
      item.id,
      item.date,
      item.time,
      item.type === 'in' ? '入库' : '出库',
      `"${item.name}"`,
      `"${item.brand}"`,
      item.amount,
      `"${item.notes || ''}"`
    ]);

    // 4. Construct CSV
    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.join(','))
    ].join('\n');

    // 5. Download
    const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', fileName);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex flex-col min-h-screen pb-24 bg-background-light dark:bg-background-dark" onClick={() => setIsExportMenuOpen(false)}>
      <header className="flex items-center justify-between px-6 pt-12 pb-4 bg-background-light dark:bg-background-dark sticky top-0 z-10">
        <h2 className="text-2xl font-bold tracking-tight text-text-primary-light dark:text-text-primary-dark">交易日志</h2>
        
        <div className="relative">
          <button 
            onClick={(e) => { e.stopPropagation(); setIsExportMenuOpen(!isExportMenuOpen); }}
            className="flex items-center justify-center size-10 rounded-full bg-white dark:bg-card-dark shadow-sm hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors active:scale-95 text-primary"
          >
            <Icon name="ios_share" className="text-[20px]" />
          </button>

          {isExportMenuOpen && (
            <div className="absolute right-0 top-full mt-2 w-40 bg-white dark:bg-[#2C2C2E] rounded-xl shadow-floating ring-1 ring-black/5 dark:ring-white/10 overflow-hidden z-30 animate-in fade-in zoom-in-95 duration-100 origin-top-right">
              <div className="py-1">
                <button 
                  onClick={() => handleExport('daily')}
                  className="w-full text-left px-4 py-3 text-sm text-slate-700 dark:text-slate-200 hover:bg-gray-50 dark:hover:bg-white/10 transition-colors flex items-center gap-2"
                >
                  <Icon name="today" className="text-[18px] text-slate-400" />
                  <span>导出日报</span>
                </button>
                <div className="h-px bg-gray-100 dark:bg-gray-700 mx-3"></div>
                <button 
                  onClick={() => handleExport('monthly')}
                  className="w-full text-left px-4 py-3 text-sm text-slate-700 dark:text-slate-200 hover:bg-gray-50 dark:hover:bg-white/10 transition-colors flex items-center gap-2"
                >
                  <Icon name="calendar_month" className="text-[18px] text-slate-400" />
                  <span>导出月报</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </header>
      
      <div className="px-6 pb-2 space-y-4">
        <div className="relative w-full group">
          <div className="absolute inset-y-0 left-0 flex items-center pl-4 pointer-events-none">
            <Icon name="search" className="text-slate-400" />
          </div>
          <input 
            type="text" 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="block w-full p-4 pl-12 text-sm text-slate-900 border border-transparent rounded-full bg-white dark:bg-card-dark dark:text-white placeholder-slate-400 focus:ring-2 focus:ring-primary focus:bg-white dark:focus:bg-card-dark shadow-sm transition-all" 
            placeholder="搜索产品、货号..." 
          />
        </div>
        <div className="flex gap-3 overflow-x-auto no-scrollbar py-1">
          <button 
            onClick={() => setFilterType('all')}
            className={`flex shrink-0 items-center justify-center px-5 h-9 rounded-full text-sm font-medium shadow-sm transition-all active:scale-95 ${
              filterType === 'all' 
                ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 shadow-md' 
                : 'bg-white dark:bg-card-dark text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-50'
            }`}
          >
            全部
          </button>
          <button 
            onClick={() => setFilterType('in')}
            className={`flex shrink-0 items-center justify-center px-5 h-9 rounded-full text-sm font-medium shadow-sm transition-all active:scale-95 ${
              filterType === 'in' 
                ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 shadow-md' 
                : 'bg-white dark:bg-card-dark text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-50'
            }`}
          >
            入库
          </button>
          <button 
            onClick={() => setFilterType('out')}
            className={`flex shrink-0 items-center justify-center px-5 h-9 rounded-full text-sm font-medium shadow-sm transition-all active:scale-95 ${
              filterType === 'out' 
                ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 shadow-md' 
                : 'bg-white dark:bg-card-dark text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-50'
            }`}
          >
            出库
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-6 pt-2 space-y-6 no-scrollbar">
        {groupedHistory.length > 0 ? (
          groupedHistory.map(([date, items]) => (
            <div key={date}>
              <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3 ml-1">{date}</h3>
              <div className="flex flex-col gap-3">
                {items.map((item) => (
                  <div key={item.id} className="group flex flex-col p-4 bg-white dark:bg-card-dark rounded-xl shadow-sm border border-slate-100 dark:border-slate-800 hover:shadow-md transition-shadow cursor-pointer">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className={`flex items-center justify-center size-12 rounded-full shrink-0 ${item.type === 'in' ? 'bg-success-bg dark:bg-emerald-900/30' : 'bg-danger-bg dark:bg-red-900/30'}`}>
                          <Icon name={item.type === 'in' ? 'arrow_upward' : 'arrow_downward'} className={item.type === 'in' ? 'text-success dark:text-emerald-400' : 'text-danger dark:text-red-400'} />
                        </div>
                        <div className="flex flex-col">
                          <p className="text-slate-900 dark:text-white text-base font-semibold leading-tight">{item.name}</p>
                          <div className="flex items-center gap-1.5 mt-1">
                            <span className="text-slate-500 dark:text-slate-400 text-xs font-medium">{item.brand}</span>
                            <span className="size-1 rounded-full bg-slate-300 dark:bg-slate-600"></span>
                            <span className="text-slate-400 text-xs">{item.time}</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex flex-col items-end gap-1">
                        <p className={`text-lg font-bold leading-none ${item.type === 'in' ? 'text-success dark:text-emerald-400' : 'text-danger dark:text-red-400'}`}>
                          {item.type === 'in' ? '+' : '-'}{item.amount}
                        </p>
                        <p className="text-xs text-slate-400">{item.type === 'in' ? '补货' : '使用'}</p>
                      </div>
                    </div>
                    {item.notes && (
                      <div className="mt-3 pt-3 border-t border-slate-50 dark:border-slate-800 flex items-start gap-2">
                         <Icon name="sticky_note_2" className="text-slate-400 text-[16px] mt-0.5" />
                         <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2">{item.notes}</p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          ))
        ) : (
          <div className="flex flex-col items-center justify-center pt-20 text-slate-400">
            <Icon name="history_toggle_off" className="text-6xl mb-4 opacity-50" />
            <p className="text-sm font-medium">没有找到相关记录</p>
          </div>
        )}
      </div>
    </div>
  );
};