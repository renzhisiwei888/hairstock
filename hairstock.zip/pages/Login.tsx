import React, { useState } from 'react';
import { Icon } from '../components/Icon';
import { useAuth } from '../context/AuthContext';

export const Login: React.FC = () => {
  const { login } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) return;

    setIsLoading(true);
    try {
      await login(email);
    } catch (error) {
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background-light dark:bg-background-dark flex flex-col justify-center px-6 py-12 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-sm flex flex-col items-center animate-fade-in">
        {/* Updated "Cute" Icon Style */}
        <div className="h-24 w-24 bg-gradient-to-tr from-blue-400 to-cyan-300 rounded-[2rem] flex items-center justify-center text-white mb-6 shadow-lg shadow-blue-200 dark:shadow-blue-900/30 ring-4 ring-white dark:ring-white/5 transform transition-transform hover:scale-105 duration-300">
          <Icon name="content_cut" className="text-[40px]" />
        </div>
        
        {/* Updated Title Text */}
        <h2 className="text-center text-3xl font-bold leading-9 tracking-tight text-slate-900 dark:text-white font-display">
          库存管理系统
        </h2>
      </div>

      <div className="mt-10 sm:mx-auto sm:w-full sm:max-w-sm animate-slide-up">
        <form className="space-y-6" onSubmit={handleSubmit}>
          <div>
            <label htmlFor="email" className="block text-sm font-medium leading-6 text-slate-900 dark:text-white ml-1">
              账号 / 邮箱
            </label>
            <div className="mt-2 relative">
              <input
                id="email"
                name="email"
                type="text"
                autoComplete="username"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="block w-full rounded-2xl border-0 py-4 pl-4 bg-white dark:bg-card-dark text-slate-900 dark:text-white shadow-sm ring-1 ring-inset ring-slate-200 dark:ring-slate-700 placeholder:text-slate-400 focus:ring-2 focus:ring-inset focus:ring-primary sm:text-sm sm:leading-6 transition-all"
                placeholder="admin / admin@hairstock.com"
              />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between ml-1">
              <label htmlFor="password" className="block text-sm font-medium leading-6 text-slate-900 dark:text-white">
                密码
              </label>
              <div className="text-sm">
                <a href="#" className="font-semibold text-primary hover:text-primary-dark transition-colors">
                  忘记密码?
                </a>
              </div>
            </div>
            <div className="mt-2 relative">
              <input
                id="password"
                name="password"
                type="password"
                autoComplete="current-password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="block w-full rounded-2xl border-0 py-4 pl-4 bg-white dark:bg-card-dark text-slate-900 dark:text-white shadow-sm ring-1 ring-inset ring-slate-200 dark:ring-slate-700 placeholder:text-slate-400 focus:ring-2 focus:ring-inset focus:ring-primary sm:text-sm sm:leading-6 transition-all"
                placeholder="••••••••"
              />
            </div>
          </div>

          <div>
            <button
              type="submit"
              disabled={isLoading}
              className="flex w-full justify-center rounded-2xl bg-primary px-3 py-4 text-sm font-semibold leading-6 text-white shadow-lg shadow-primary/30 hover:bg-blue-600 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary transition-all active:scale-[0.98] disabled:opacity-70 disabled:cursor-not-allowed"
            >
              {isLoading ? (
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  登录中...
                </div>
              ) : (
                '登录'
              )}
            </button>
          </div>
        </form>

        <p className="mt-10 text-center text-xs text-slate-500 dark:text-slate-400">
          还没账号?{' '}
          <a href="#" className="font-semibold leading-6 text-primary hover:text-primary-dark transition-colors">
            联系管理员注册
          </a>
        </p>
      </div>
    </div>
  );
};