import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Icon } from '../components/Icon';

interface ProductStat {
  id: string;
  name: string;
  variant: string;
  consumed: number;
  inStock: number;
  trend: 'up' | 'down' | 'stable';
  trendValue: number;
  turnoverRate: string; // e.g., "High", "Medium", "Low"
}

const mockProductStats: ProductStat[] = [
  { id: '1', name: '欧莱雅 漂发粉', variant: '500g 罐装', consumed: 42, inStock: 8, trend: 'up', trendValue: 12, turnoverRate: 'High' },
  { id: '2', name: 'Olaplex 4号', variant: '洗发水, 250ml', consumed: 38, inStock: 12, trend: 'up', trendValue: 8, turnoverRate: 'High' },
  { id: '3', name: 'Wella 威娜 染发膏', variant: '色调剂', consumed: 28, inStock: 3, trend: 'stable', trendValue: 0, turnoverRate: 'Med' },
  { id: '4', name: 'Redken Shades EQ', variant: '光泽护发', consumed: 24, inStock: 24, trend: 'down', trendValue: 5, turnoverRate: 'Low' },
  { id: '5', name: 'Schwarzkopf Igora', variant: 'Royal 染发剂', consumed: 15, inStock: 15, trend: 'up', trendValue: 2, turnoverRate: 'Med' },
  { id: '6', name: 'K18 发膜', variant: '免洗发膜 50ml', consumed: 12, inStock: 5, trend: 'up', trendValue: 15, turnoverRate: 'High' },
  { id: '7', name: 'Joico K-PAK', variant: '洗发水', consumed: 10, inStock: 20, trend: 'down', trendValue: 10, turnoverRate: 'Low' },
  { id: '8', name: 'Moroccanoil', variant: '护发精油', consumed: 8, inStock: 18, trend: 'stable', trendValue: 0, turnoverRate: 'Low' },
];

export const ProductPerformance: React.FC = () => {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');

  const filteredStats = mockProductStats.filter(p => 
    p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.variant.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="flex flex-col min-h-screen bg-background-light dark:bg-background-dark">
      <header className="pt-8 pb-2 px-4 sticky top-0 bg-background-light/95 dark:bg-background-dark/95 backdrop-blur-md z-10 border-b border-gray-200 dark:border-gray-800">
        <div className="flex items-center gap-3 mb-4">
          <button onClick={() => navigate(-1)} className="p-2 -ml-2 rounded-full hover:bg-black/5 dark:hover:bg-white/10 transition-colors">
            <Icon name="arrow_back_ios_new" className="text-text-primary-light dark:text-text-primary-dark" />
          </button>
          <h1 className="text-xl font-bold text-text-primary-light dark:text-text-primary-dark">产品表现明细</h1>
        </div>
        
        <div className="relative mb-2">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Icon name="search" className="text-slate-400 text-[20px]" />
          </div>
          <input 
            type="text" 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="block w-full pl-10 pr-3 py-2.5 bg-white dark:bg-[#1C1C1E] border border-gray-200 dark:border-gray-800 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary/50 text-slate-900 dark:text-white"
            placeholder="搜索产品..."
          />
        </div>
      </header>

      <main className="flex-1 overflow-y-auto no-scrollbar p-4">
        <div className="flex flex-col gap-3">
           {/* Table Header (Visual) */}
           <div className="grid grid-cols-12 gap-2 px-3 pb-1 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wide">
             <div className="col-span-6">产品</div>
             <div className="col-span-3 text-center">消耗</div>
             <div className="col-span-3 text-right">库存</div>
           </div>

          {filteredStats.map((stat) => (
            <div key={stat.id} className="bg-white dark:bg-card-dark p-3.5 rounded-xl shadow-sm border border-gray-100 dark:border-gray-800 grid grid-cols-12 gap-2 items-center active:bg-gray-50 dark:active:bg-gray-800 transition-colors">
              
              {/* Product Info */}
              <div className="col-span-6 min-w-0 pr-2">
                <p className="text-sm font-bold text-slate-900 dark:text-white truncate">{stat.name}</p>
                <p className="text-xs text-slate-500 dark:text-slate-400 truncate">{stat.variant}</p>
                <div className="mt-1 flex items-center gap-1.5">
                   <span className={`text-[10px] px-1.5 py-0.5 rounded font-medium ${
                     stat.turnoverRate === 'High' ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400' :
                     stat.turnoverRate === 'Med' ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400' :
                     'bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400'
                   }`}>
                     {stat.turnoverRate === 'High' ? '高周转' : stat.turnoverRate === 'Med' ? '一般' : '低周转'}
                   </span>
                </div>
              </div>

              {/* Consumption Stats */}
              <div className="col-span-3 flex flex-col items-center justify-center border-l border-gray-100 dark:border-gray-800 pl-2">
                <span className="text-base font-bold text-slate-900 dark:text-white">{stat.consumed}</span>
                <div className="flex items-center gap-0.5">
                  {stat.trend === 'up' && <Icon name="trending_up" className="text-green-500 text-[12px]" />}
                  {stat.trend === 'down' && <Icon name="trending_down" className="text-red-500 text-[12px]" />}
                  {stat.trend === 'stable' && <Icon name="remove" className="text-gray-400 text-[12px]" />}
                  {stat.trend !== 'stable' && (
                    <span className={`text-[10px] font-medium ${stat.trend === 'up' ? 'text-green-500' : 'text-red-500'}`}>
                      {stat.trendValue}%
                    </span>
                  )}
                </div>
              </div>

              {/* Stock Level */}
              <div className="col-span-3 flex flex-col items-end justify-center pl-2">
                 <span className={`text-base font-bold ${stat.inStock < 5 ? 'text-orange-500' : 'text-slate-900 dark:text-white'}`}>
                   {stat.inStock}
                 </span>
                 <span className="text-[10px] text-slate-400">剩余</span>
              </div>

            </div>
          ))}

          {filteredStats.length === 0 && (
             <div className="flex flex-col items-center justify-center py-10 text-slate-400">
               <Icon name="search_off" className="text-4xl mb-2 opacity-30" />
               <p className="text-sm">未找到相关数据</p>
             </div>
          )}
        </div>
      </main>
    </div>
  );
};
