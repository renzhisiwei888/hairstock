import React, { useState, useMemo } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Icon } from '../components/Icon';
import { Product } from '../types';

const initialProducts: Product[] = [
  {
    id: '1',
    name: '欧莱雅 漂发粉',
    brand: 'L\'Oreal',
    variant: '500g 罐装',
    quantity: 8,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBaEygzPpKhoWszYi5Lf9aORG9Wo5zhcJh3PDt8qjur6sFf1NhdXy83A7yc6w7bsqQ8YSQES8kRC-20JpeXGqb2dKN6eKycvUY0WfZQJGOnhQ-kxZwrK0AUbEGoG5Gl6oOhSfMOZ_31QfB78GVShY4XOFDCumNb9hkzGYoAo7P_vuuEk8PbgOPPT9z4Z8y6o3jsBn-K9suyo6lytp62w9xcIW0V2pjRrG_hKNQOLmnF7n-dts8hHG6VKDJKAilLa1jc7U23-gRts2Sy',
  },
  {
    id: '2',
    name: 'Olaplex 4号',
    brand: 'Olaplex',
    variant: '洗发水, 250ml',
    quantity: 12,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBOYshIISvtMrrJADgsw01lSMdIbMho4qhsGblYsXKWYWqpee0t8Q9VHyA3Dv0QtCrsUgXCodGbBql6tPzfga8BcMgnNx7OZ7fZQYHrXShvs7HZHxHDpQ-V0Yg4VH8BXrr1qwwlW1cOQrBoDCGomrgPTdAfIHYqxKZV2Qyqmfc2j3zrST5XsUPdLlUpwHVTrytuQGtGC0tvcn46YGZTt2q-7rAsnHTP3vElNaaU9GEk1-TysVVWYyadU0UCdvDetiLSSSSKnSHatY03',
  },
  {
    id: '3',
    name: 'Wella 威娜 染发膏',
    brand: 'Wella',
    variant: '色调剂',
    quantity: 3,
    lowStock: true,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuB4HmjtfJN2s69fSsT-xm-dhkkoE7XoGYBbBWhOcqxycLJryIBHebx5q2CBO8YbKVfC7DxHleKUe4ywk0_4-aPGlUpRzk_M0V1IOFZnay78hTWrMUK1IyJQTWlubKNle7AcUsCi3Grmd7S3EjIrnemENPTWDxdwGopt8hnh4jTaxvKguvdqJXe8MP7iuepxrruf7H0g0S8gAWopVP6oBfksK-uaNUxgaGwXVGKaoJ1SGBHlUBZGAvTDVcyeeUHw_hGcaYikOMYmQEzH',
  },
  {
    id: '4',
    name: 'Redken Shades EQ',
    brand: 'Redken',
    variant: '光泽护发',
    quantity: 24,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuClzOmGD9s9NeWLQUq_f0aWJKK72-Zn4YAER7WcmZOTbbmmyLAyyKNnpRlBIiX6tTpnWBFgdqe2lIerp1z68VSy_g08NfmWiCybapyyVcCQv_g5rrJh3nQvk1hnK5VkWl2v_Me2bt-gfuVMTU17QkmFeHW91tokqjPj1OtjIjf0w2u9g_XWyVz-v23yAnZy2h7d7-4jzWIUWIMA6lXegRzU47q1OmvH4DIXxz1VnQbLrFophJ79TaXOtUhMxRi6UDqM6oExGyfWLe1n',
  },
  {
    id: '5',
    name: 'Schwarzkopf Igora',
    brand: 'Schwarzkopf',
    variant: 'Royal 染发剂',
    quantity: 15,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDtFkoUWkaI633ksan1MbJU6Xm4cTSTpOCmZtIW4MV06zB03FRdi7BtXvW23BjLCRihsWtHkE48IjlocmmVDZpx0jBpG_FSjtmpLnHkzWwN3MdxnhR7ooMfgzrUh4dKStYhWwknddDYYtyAnELwLDOagi0pnco-sA6gZ90mcU-evUqK1YHIjmI4FoWT46ErZd1BcxJPxNeFkJHF4OesgHP9CNH6YEn6dSnKIYm4FYMYl0qj-RSAxFXF_3dlsfwA6cBW5fTIWwR3wdfa',
  }
];

type SortOption = 'default' | 'quantityAsc' | 'quantityDesc';

export const Dashboard: React.FC = () => {
  const navigate = useNavigate();
  // setProducts removed as it is not used in this view anymore
  const [products] = useState<Product[]>(initialProducts);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortOption, setSortOption] = useState<SortOption>('default');
  const [isSortMenuOpen, setIsSortMenuOpen] = useState(false);

  const handleProductClick = (product: Product) => {
    navigate(`/adjust/${product.id}`, { state: { product } });
  };

  const filteredAndSortedProducts = useMemo(() => {
    let result = products.filter(p => 
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
      p.brand.toLowerCase().includes(searchQuery.toLowerCase())
    );

    if (sortOption === 'quantityAsc') {
      result.sort((a, b) => a.quantity - b.quantity);
    } else if (sortOption === 'quantityDesc') {
      result.sort((a, b) => b.quantity - a.quantity);
    }

    return result;
  }, [products, searchQuery, sortOption]);

  const toggleSort = () => setIsSortMenuOpen(!isSortMenuOpen);
  
  const selectSort = (option: SortOption) => {
    setSortOption(option);
    setIsSortMenuOpen(false);
  };

  return (
    <div className="flex flex-col min-h-screen pb-24" onClick={() => setIsSortMenuOpen(false)}>
      <header className="flex flex-col gap-4 p-4 pt-12 pb-2 sticky top-0 z-20 bg-background-light/95 dark:bg-background-dark/95 backdrop-blur-md">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold tracking-tight text-text-primary-light dark:text-text-primary-dark">库存管理</h1>
          <Link to="/settings" className="p-2 rounded-full hover:bg-black/5 dark:hover:bg-white/10 transition-colors">
            <Icon name="account_circle" className="text-primary text-[28px]" />
          </Link>
        </div>
        <div className="relative group">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Icon name="search" className="text-primary dark:text-primary-dark text-[22px]" />
          </div>
          <input 
            type="text" 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="block w-full pl-10 pr-3 py-3 border border-gray-200 dark:border-gray-800 rounded-xl bg-white dark:bg-[#1C1C1E] text-text-primary-light dark:text-text-primary-dark placeholder-text-secondary-light dark:placeholder-text-secondary-dark focus:ring-2 focus:ring-primary focus:border-transparent transition-all text-[17px] leading-snug shadow-sm" 
            placeholder="搜索产品、品牌..." 
          />
        </div>
      </header>

      <main className="flex-1 flex flex-col gap-6 px-4 pt-2 overflow-y-auto no-scrollbar">
        <section className="grid grid-cols-2 gap-3">
          <div className="bg-card-light dark:bg-card-dark p-4 rounded-xl shadow-ios flex flex-col justify-between h-[110px]">
            <div className="flex items-start justify-between">
              <span className="bg-primary/10 p-1.5 rounded-lg flex items-center justify-center">
                 <Icon name="input" className="text-primary text-[20px]" />
              </span>
              <div className="flex items-center gap-1 bg-green-100 dark:bg-green-900/30 px-2 py-0.5 rounded-full">
                <Icon name="trending_up" className="text-[#078838] dark:text-green-400 text-[14px]" />
                <span className="text-xs font-semibold text-[#078838] dark:text-green-400">12%</span>
              </div>
            </div>
            <div>
              <p className="text-[13px] font-medium text-text-secondary-light dark:text-text-secondary-dark uppercase tracking-wide">入库总量</p>
              <p className="text-2xl font-bold tracking-tight text-text-primary-light dark:text-text-primary-dark">342</p>
            </div>
          </div>
          <div className="bg-card-light dark:bg-card-dark p-4 rounded-xl shadow-ios flex flex-col justify-between h-[110px]">
            <div className="flex items-start justify-between">
              <span className="bg-primary/10 p-1.5 rounded-lg flex items-center justify-center">
                <Icon name="exit_to_app" className="text-primary text-[20px]" />
              </span>
              <div className="flex items-center gap-1 bg-orange-100 dark:bg-orange-900/30 px-2 py-0.5 rounded-full">
                <Icon name="trending_down" className="text-[#e73908] dark:text-orange-400 text-[14px]" />
                <span className="text-xs font-semibold text-[#e73908] dark:text-orange-400">5%</span>
              </div>
            </div>
            <div>
              <p className="text-[13px] font-medium text-text-secondary-light dark:text-text-secondary-dark uppercase tracking-wide">消耗总量</p>
              <p className="text-2xl font-bold tracking-tight text-text-primary-light dark:text-text-primary-dark">189</p>
            </div>
          </div>
        </section>

        <section className="flex flex-col gap-4">
          <div className="flex items-center justify-between px-1 relative">
            <h2 className="text-lg font-semibold text-text-primary-light dark:text-text-primary-dark">产品列表</h2>
            <div className="relative">
              <button 
                onClick={(e) => { e.stopPropagation(); toggleSort(); }}
                className="text-primary text-sm font-medium flex items-center gap-1 hover:opacity-80 transition-opacity"
              >
                <span>
                  {sortOption === 'default' && '默认排序'}
                  {sortOption === 'quantityAsc' && '库存: 低到高'}
                  {sortOption === 'quantityDesc' && '库存: 高到低'}
                </span>
                <Icon name="sort" className="text-[18px]" />
              </button>
              
              {isSortMenuOpen && (
                <div className="absolute right-0 top-full mt-2 w-40 bg-white dark:bg-[#2C2C2E] rounded-xl shadow-floating ring-1 ring-black/5 dark:ring-white/10 overflow-hidden z-30">
                  <div className="py-1">
                    <button 
                      onClick={() => selectSort('default')}
                      className={`w-full text-left px-4 py-2.5 text-sm hover:bg-gray-50 dark:hover:bg-white/10 transition-colors ${sortOption === 'default' ? 'text-primary font-medium' : 'text-gray-700 dark:text-gray-200'}`}
                    >
                      默认排序
                    </button>
                    <button 
                      onClick={() => selectSort('quantityAsc')}
                      className={`w-full text-left px-4 py-2.5 text-sm hover:bg-gray-50 dark:hover:bg-white/10 transition-colors ${sortOption === 'quantityAsc' ? 'text-primary font-medium' : 'text-gray-700 dark:text-gray-200'}`}
                    >
                      库存: 低到高
                    </button>
                    <button 
                      onClick={() => selectSort('quantityDesc')}
                      className={`w-full text-left px-4 py-2.5 text-sm hover:bg-gray-50 dark:hover:bg-white/10 transition-colors ${sortOption === 'quantityDesc' ? 'text-primary font-medium' : 'text-gray-700 dark:text-gray-200'}`}
                    >
                      库存: 高到低
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
          <div className="flex flex-col gap-3 pb-8">
            {filteredAndSortedProducts.length > 0 ? (
              filteredAndSortedProducts.map((product) => (
                <div 
                  key={product.id}
                  onClick={() => handleProductClick(product)}
                  className={`bg-card-light dark:bg-card-dark p-3 rounded-2xl shadow-ios flex items-center gap-3 cursor-pointer active:scale-[0.98] transition-transform ${product.lowStock ? 'ring-1 ring-orange-500/20' : ''}`}
                >
                  <div className="shrink-0 relative">
                    <div 
                      className="w-16 h-16 rounded-xl bg-gray-100 dark:bg-gray-800 bg-cover bg-center border border-gray-100 dark:border-gray-700" 
                      style={{ backgroundImage: `url('${product.image}')` }}
                    ></div>
                    {product.lowStock && (
                      <div className="absolute -top-2 -left-2 bg-orange-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full shadow-sm">LOW</div>
                    )}
                  </div>
                  <div className="flex-1 min-w-0 flex flex-col justify-center gap-0.5">
                    <h3 className="text-[16px] font-semibold text-text-primary-light dark:text-text-primary-dark truncate">{product.name}</h3>
                    <div className="flex items-center gap-1">
                      <p className="text-[14px] text-text-secondary-light dark:text-text-secondary-dark truncate">{product.variant}</p>
                      {product.lowStock && (
                        <>
                          <span className="w-1 h-1 rounded-full bg-orange-500"></span>
                          <p className="text-[12px] font-medium text-orange-500">尽快补货</p>
                        </>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center justify-center bg-background-light dark:bg-[#2C2C2E] h-10 min-w-[3.5rem] px-2 rounded-xl">
                    <span className={`text-xl font-bold tabular-nums ${product.lowStock ? 'text-orange-500' : 'text-text-primary-light dark:text-text-primary-dark'}`}>
                      {product.quantity}
                    </span>
                  </div>
                </div>
              ))
            ) : (
              <div className="flex flex-col items-center justify-center py-10 text-text-secondary-light dark:text-text-secondary-dark">
                <Icon name="search_off" className="text-[48px] opacity-20 mb-2" />
                <p>未找到相关产品</p>
              </div>
            )}
          </div>
        </section>
      </main>
    </div>
  );
};
