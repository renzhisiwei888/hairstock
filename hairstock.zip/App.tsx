import React from 'react';
import { HashRouter, Routes, Route, Outlet, Navigate } from 'react-router-dom';
import { Dashboard } from './pages/Dashboard';
import { Analytics } from './pages/Analytics';
import { History } from './pages/History';
import { Settings } from './pages/Settings';
import { StockAdjustment } from './pages/StockAdjustment';
import { AddProduct } from './pages/AddProduct';
import { ProductPerformance } from './pages/ProductPerformance';
import { Login } from './pages/Login';
import { Layout } from './components/Layout';
import { AuthProvider, useAuth } from './context/AuthContext';

// Layout wrapper for routes that need the bottom nav
const MainLayout = () => {
  return (
    <Layout>
      <Outlet />
    </Layout>
  );
};

// Component to handle auth guarding
const AppRoutes: React.FC = () => {
  const { isAuthenticated } = useAuth();

  if (!isAuthenticated) {
    return <Login />;
  }

  return (
    <Routes>
      <Route element={<MainLayout />}>
        <Route path="/" element={<Dashboard />} />
        <Route path="/analytics" element={<Analytics />} />
        <Route path="/history" element={<History />} />
      </Route>
      
      {/* Pages that cover the nav or have their own layout */}
      <Route path="/analytics/products" element={<ProductPerformance />} />
      <Route path="/settings" element={<Settings />} />
      <Route path="/adjust/:id" element={<StockAdjustment />} />
      <Route path="/add" element={<AddProduct />} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
};

const App: React.FC = () => {
  return (
    <AuthProvider>
      <HashRouter>
        <AppRoutes />
      </HashRouter>
    </AuthProvider>
  );
};

export default App;